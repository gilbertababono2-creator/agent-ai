const OpenAI = require('openai');
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are a multi-agent AI system with three specialized agents:
1. App Builder Agent: expert in coding, generating apps, debugging, and deployment.
2. Marketing Agent: expert in creating viral content, ads, SEO, and branding.
3. Business Automation Agent: expert in scheduling, customer support, and workflow automation.

When a user asks something, decide which agent(s) to engage. If you need to generate code, respond with a code block. For content, output the content directly. You can call tools by returning a JSON object with "action" and "parameters". Available tools:
- generate_react_app(prompt): returns full React app code.
- generate_landing_page(prompt): returns HTML/CSS landing page.
- generate_seo_content(topic): returns SEO blog.
- schedule_appointment(user_details): books appointment.
- send_whatsapp_message(to, message): sends WhatsApp via Twilio.

Always be helpful and concise.`;

// In-memory conversation store (use Firestore in production)
const conversations = {};

async function routeMessage(userId, message, history = []) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...history,
    { role: 'user', content: message }
  ];

  const completion = await openai.chat.completions.create({
    model: 'gpt-4-turbo',
    messages,
    temperature: 0.7,
    max_tokens: 2000
  });

  let reply = completion.choices[0].message.content;

  // Simple tool calling detection (could use function calling in production)
  if (reply.includes('{') && reply.includes('}')) {
    try {
      const parsed = JSON.parse(reply);
      if (parsed.action === 'generate_react_app') {
        reply = generateReactAppCode(parsed.parameters.prompt);
      } else if (parsed.action === 'schedule_appointment') {
        // Handle appointment via Twilio etc.
        reply = `Appointment scheduled for ${parsed.parameters.user_details}`;
      }
      // ... other tools
    } catch {}
  }

  return reply;
}

function generateReactAppCode(prompt) {
  // In real implementation, you'd use a code generation model or fine-tuned GPT
  return `// Generated React App based on: "${prompt}"
import React from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-black text-white p-8">
      <h1 className="text-4xl font-bold mb-4">${prompt}</h1>
      <p>Your AI-generated app is ready!</p>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);`;
}

module.exports = { routeMessage };