const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const agentsRoutes = require('./routes/agents');
const paymentsRoutes = require('./routes/payments');
const appointmentsRoutes = require('./routes/appointments');
// projects, content routes similar

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
});
app.use('/api/', limiter);

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/agents', agentsRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/appointments', appointmentsRoutes);

// Health check
app.get('/', (req, res) => res.send('SuperAgent AI API Running'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));