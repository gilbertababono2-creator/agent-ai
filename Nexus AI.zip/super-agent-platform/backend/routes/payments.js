const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { db } = require('../firebase-admin');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;

// Initiate subscription
router.post('/subscribe', authMiddleware, async (req, res) => {
  const { plan } = req.body;
  const email = req.user.email;
  const amount = plan === 'premium' ? 29 : 0; // USD
  const reference = `sub_${uuidv4()}`;

  // Save pending subscription
  await db.collection('subscriptions').doc(reference).set({
    userId: req.user.uid,
    email,
    plan,
    amount,
    reference,
    status: 'pending',
    createdAt: new Date()
  });

  res.json({ reference, amount, email });
});

// Verify payment (called after Paystack success)
router.post('/verify', authMiddleware, async (req, res) => {
  const { reference } = req.body;
  try {
    const response = await axios.get(`https://api.paystack.co/transaction/verify/${reference}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` }
    });

    const { status, amount, customer } = response.data.data;
    if (status === 'success') {
      await db.collection('subscriptions').doc(reference).update({
        status: 'active',
        verifiedAt: new Date()
      });
      // Update user plan
      await db.collection('users').doc(req.user.uid).update({
        plan: 'premium',
        subscriptionRef: reference
      });
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Payment not successful' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Verification failed' });
  }
});

// Paystack webhook (no auth)
router.post('/webhook', express.json(), async (req, res) => {
  const event = req.body;
  // Verify signature (recommended)
  if (event.event === 'charge.success') {
    const reference = event.data.reference;
    await db.collection('subscriptions').doc(reference).update({ status: 'active', webhook: true });
    // Upgrade user...
  }
  res.sendStatus(200);
});

module.exports = router;