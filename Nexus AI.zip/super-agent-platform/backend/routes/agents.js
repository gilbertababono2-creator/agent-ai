const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { routeMessage } = require('../utils/aiAgentRouter');

// Main chat endpoint
router.post('/chat', authMiddleware, async (req, res) => {
  try {
    const { message, history } = req.body;
    const userId = req.user.uid;
    const reply = await routeMessage(userId, message, history);
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'AI processing failed' });
  }
});

// Generate code specifically
router.post('/generate-code', authMiddleware, async (req, res) => {
  const { prompt, type } = req.body;
  const fullPrompt = `Generate a complete ${type} code for: ${prompt}. Return only code.`;
  const reply = await routeMessage(req.user.uid, fullPrompt);
  res.json({ code: reply });
});

// Generate content
router.post('/generate-content', authMiddleware, async (req, res) => {
  const { type, topic, details } = req.body;
  const fullPrompt = `Act as Marketing Agent. Create a ${type} about "${topic}". Additional details: ${JSON.stringify(details)}`;
  const content = await routeMessage(req.user.uid, fullPrompt);
  res.json({ content });
});

module.exports = router;