const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { db } = require('../firebase-admin');

router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, email, date, time, type } = req.body;
    await db.collection('appointments').add({
      userId: req.user.uid,
      name,
      email,
      date,
      time,
      type,
      createdAt: new Date(),
      status: 'scheduled'
    });
    res.json({ success: true, message: 'Appointment booked' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/', authMiddleware, async (req, res) => {
  const snapshot = await db.collection('appointments')
    .where('userId', '==', req.user.uid)
    .orderBy('createdAt', 'desc')
    .get();
  const appointments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  res.json(appointments);
});

module.exports = router;