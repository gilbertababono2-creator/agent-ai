const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { db } = require('../firebase-admin');

// Create a new project
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, description, type, code, generatedBy } = req.body;
    const projectRef = await db.collection('projects').add({
      userId: req.user.uid,
      name,
      description,
      type: type || 'web-app',
      code: code || '',
      generatedBy: generatedBy || 'app-builder',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    res.status(201).json({ id: projectRef.id, message: 'Project created' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all projects for user
router.get('/', authMiddleware, async (req, res) => {
  try {
    const snapshot = await db.collection('projects')
      .where('userId', '==', req.user.uid)
      .orderBy('createdAt', 'desc')
      .get();
    const projects = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(projects);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single project
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const doc = await db.collection('projects').doc(req.params.id).get();
    if (!doc.exists || doc.data().userId !== req.user.uid) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ id: doc.id, ...doc.data() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update project code
router.patch('/:id', authMiddleware, async (req, res) => {
  try {
    const { code, name } = req.body;
    const docRef = db.collection('projects').doc(req.params.id);
    const doc = await docRef.get();
    if (!doc.exists || doc.data().userId !== req.user.uid) {
      return res.status(404).json({ error: 'Project not found' });
    }
    await docRef.update({
      code: code || doc.data().code,
      name: name || doc.data().name,
      updatedAt: new Date()
    });
    res.json({ message: 'Project updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete project
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const docRef = db.collection('projects').doc(req.params.id);
    const doc = await docRef.get();
    if (!doc.exists || doc.data().userId !== req.user.uid) {
      return res.status(404).json({ error: 'Project not found' });
    }
    await docRef.delete();
    res.json({ message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;