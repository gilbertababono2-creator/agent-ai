const express = require('express');
const router = express.Router();
const { auth } = require('../firebase-admin');

// Create a custom token for privileged actions (optional)
router.post('/custom-token', async (req, res) => {
  try {
    const { uid } = req.body;
    if (!uid) return res.status(400).json({ error: 'UID required' });
    const customToken = await auth.createCustomToken(uid);
    res.json({ token: customToken });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Verify ID token (used for debugging)
router.post('/verify-token', async (req, res) => {
  try {
    const { token } = req.body;
    const decoded = await auth.verifyIdToken(token);
    res.json({ valid: true, user: decoded });
  } catch (err) {
    res.status(401).json({ valid: false, error: err.message });
  }
});

module.exports = router;