const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { db } = require('../firebase-admin');

// Save generated content
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { type, topic, content, metadata } = req.body;
    const docRef = await db.collection('generated_content').add({
      userId: req.user.uid,
      type,       // e.g., 'linkedin', 'blog', 'ad'
      topic,
      content,
      metadata: metadata || {},
      createdAt: new Date()
    });
    res.status(201).json({ id: docRef.id, message: 'Content saved' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's generated content
router.get('/', authMiddleware, async (req, res) => {
  try {
    const snapshot = await db.collection('generated_content')
      .where('userId', '==', req.user.uid)
      .orderBy('createdAt', 'desc')
      .limit(50)
      .get();
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete content
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const docRef = db.collection('generated_content').doc(req.params.id);
    const doc = await docRef.get();
    if (!doc.exists || doc.data().userId !== req.user.uid) {
      return res.status(404).json({ error: 'Content not found' });
    }
    await docRef.delete();
    res.json({ message: 'Content deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;