/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        neon: {
          purple: '#9D4EDD',
          blue: '#3A86FF',
          pink: '#FF006E',
        },
        glass: {
          bg: 'rgba(17, 17, 17, 0.6)',
          border: 'rgba(255, 255, 255, 0.1)',
        }
      },
      backdropBlur: {
        xs: '2px',
      }
    },
  },
  plugins: [],
}