import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiUser, FiCreditCard, FiBell, FiShield } from 'react-icons/fi';
import { initiateSubscription } from '../services/api';
import { initializePaystackPayment } from '../services/paystack';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

export default function Settings() {
  const { user } = useAuth();
  const [plan, setPlan] = useState('free');

  const handleSubscribe = async () => {
    try {
      const res = await initiateSubscription('premium');
      const { reference, amount, email } = res.data;
      initializePaystackPayment(email, amount, reference, async (transaction) => {
        await fetch(`${import.meta.env.VITE_API_URL}/api/payments/verify`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${user.token}` },
          body: JSON.stringify({ reference: transaction.reference })
        });
        setPlan('premium');
        toast.success('Subscription activated!');
      });
    } catch (err) {
      toast.error('Subscription failed');
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <motion.h1 className="text-2xl font-bold flex items-center gap-2"><FiUser /> Profile Settings</motion.h1>
      
      <div className="glass p-5">
        <div className="flex items-center gap-4 mb-6">
          <img src={user?.photoURL || 'https://ui-avatars.com/api/?name=User&background=9D4EDD&color=fff'} className="w-16 h-16 rounded-full" />
          <div>
            <h3 className="font-semibold">{user?.displayName || 'User'}</h3>
            <p className="text-gray-400">{user?.email}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
            <div className="flex items-center gap-3"><FiCreditCard className="text-neon-purple" /><span>Current Plan</span></div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold capitalize">{plan}</span>
              {plan !== 'premium' && (
                <button onClick={handleSubscribe} className="py-1.5 px-4 bg-gradient-to-r from-neon-purple to-neon-blue rounded-lg text-sm font-medium">
                  Upgrade to Premium
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
            <div className="flex items-center gap-3"><FiBell /><span>Notifications</span></div>
            <div className="w-10 h-6 bg-gray-700 rounded-full flex items-center cursor-pointer"><div className="w-5 h-5 bg-neon-purple rounded-full ml-1"></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}