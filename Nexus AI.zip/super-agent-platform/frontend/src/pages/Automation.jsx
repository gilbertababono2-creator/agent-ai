import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiCalendar, FiMessageSquare, FiBell, FiCreditCard } from 'react-icons/fi';
import { createAppointment } from '../services/api';
import toast from 'react-hot-toast';

export default function Automation() {
  const [appointment, setAppointment] = useState({ name: '', email: '', date: '', time: '', type: 'consultation' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createAppointment(appointment);
      toast.success('Appointment booked!');
      setAppointment({ name: '', email: '', date: '', time: '', type: 'consultation' });
    } catch (err) {
      toast.error('Booking failed');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <motion.h1 className="text-2xl font-bold flex items-center gap-2">
        <FiCalendar className="text-neon-pink" /> Business Automation
      </motion.h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Appointment Scheduler */}
        <div className="glass p-5 lg:col-span-1">
          <h3 className="text-lg font-semibold mb-4">Book Appointment</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="text" placeholder="Full Name" value={appointment.name} onChange={e => setAppointment({...appointment, name: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white" required />
            <input type="email" placeholder="Email" value={appointment.email} onChange={e => setAppointment({...appointment, email: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white" required />
            <input type="date" value={appointment.date} onChange={e => setAppointment({...appointment, date: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white" required />
            <input type="time" value={appointment.time} onChange={e => setAppointment({...appointment, time: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white" required />
            <button type="submit" disabled={loading} className="w-full py-3 bg-neon-pink/20 text-neon-pink rounded-lg font-semibold hover:bg-neon-pink/30 transition-colors disabled:opacity-50">
              {loading ? 'Booking...' : 'Schedule'}
            </button>
          </form>
        </div>

        {/* WhatsApp AI & Automation Features */}
        <div className="lg:col-span-2 space-y-4">
          <div className="glass p-5 flex items-center gap-4">
            <FiMessageSquare className="text-green-400" size={24} />
            <div>
              <h4 className="font-semibold">WhatsApp AI Assistant</h4>
              <p className="text-sm text-gray-400">Auto-reply to customer inquiries via Twilio</p>
            </div>
            <div className="ml-auto">
              <div className="w-10 h-6 bg-gray-700 rounded-full flex items-center cursor-pointer" onClick={() => {}}>
                <div className="w-5 h-5 bg-neon-purple rounded-full ml-1"></div>
              </div>
            </div>
          </div>
          <div className="glass p-5 flex items-center gap-4">
            <FiBell className="text-yellow-400" size={24} />
            <div>
              <h4 className="font-semibold">Smart Reminders</h4>
              <p className="text-sm text-gray-400">Automatic SMS/email reminders before appointments</p>
            </div>
          </div>
          <div className="glass p-5 flex items-center gap-4">
            <FiCreditCard className="text-neon-blue" size={24} />
            <div>
              <h4 className="font-semibold">Subscription & Billing</h4>
              <p className="text-sm text-gray-400">Manage plans and invoices</p>
            </div>
            <button className="ml-auto py-2 px-4 bg-neon-blue/20 text-neon-blue rounded-lg text-sm">View</button>
          </div>
        </div>
      </div>
    </div>
  );
}