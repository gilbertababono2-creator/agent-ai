import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiTrendingUp, FiHash, FiFileText, FiCamera } from 'react-icons/fi';
import { generateContent } from '../services/api';
import toast from 'react-hot-toast';

const contentTypes = [
  { key: 'linkedin', label: 'LinkedIn Post', icon: FiTrendingUp },
  { key: 'tiktok', label: 'TikTok Caption', icon: FiHash },
  { key: 'blog', label: 'SEO Blog', icon: FiFileText },
  { key: 'ad', label: 'Ad Copy', icon: FiCamera },
];

export default function Marketing() {
  const [topic, setTopic] = useState('');
  const [selectedType, setSelectedType] = useState('linkedin');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!topic.trim()) return toast.error('Please enter a topic');
    setLoading(true);
    try {
      const res = await generateContent(selectedType, topic, {});
      setResult(res.data.content);
      toast.success('Content generated!');
    } catch (err) {
      toast.error('Generation failed');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <motion.h1 className="text-2xl font-bold flex items-center gap-2">
        <FiTrendingUp className="text-neon-blue" /> Marketing Agent
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {contentTypes.map(type => (
          <button
            key={type.key}
            onClick={() => setSelectedType(type.key)}
            className={`glass p-4 flex items-center gap-3 transition-all ${
              selectedType === type.key ? 'border-neon-purple neon-glow' : 'border-transparent'
            }`}
          >
            <type.icon className="text-neon-purple" size={20} />
            <span className="font-medium">{type.label}</span>
          </button>
        ))}
      </div>

      <div className="glass p-5">
        <label className="block text-sm text-gray-400 mb-2">Topic / Keywords</label>
        <textarea
          value={topic}
          onChange={e => setTopic(e.target.value)}
          placeholder="e.g. Launching a new AI productivity tool..."
          className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-neon-purple focus:outline-none h-24 resize-none"
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 py-3 px-6 bg-gradient-to-r from-neon-purple to-neon-blue rounded-lg font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Content'}
        </button>
      </div>

      {result && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass p-5">
          <h3 className="text-lg font-semibold mb-3">Generated Content</h3>
          <div className="whitespace-pre-wrap text-gray-300">{result}</div>
        </motion.div>
      )}
    </div>
  );
}