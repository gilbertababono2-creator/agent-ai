import { useState } from 'react';
import { motion } from 'framer-motion';
import CodeEditor from '../components/CodeEditor';
import Preview from '../components/Preview';
import ChatPanel from '../components/ChatPanel';
import { FiCode, FiPlay, FiDownload } from 'react-icons/fi';

export default function AppBuilder() {
  const [code, setCode] = useState(`// Generated React component\nimport React from 'react';\n\nexport default function App() {\n  return (\n    <div className="p-8 bg-gray-900 text-white min-h-screen">\n      <h1 className="text-3xl font-bold text-purple-400">My AI App</h1>\n      <p>Start building!</p>\n    </div>\n  );\n}`);
  const [showPreview, setShowPreview] = useState(false);

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col space-y-4">
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold flex items-center gap-2">
        <FiCode className="text-neon-purple" /> App Builder
      </motion.h1>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">
        {/* Code Editor */}
        <div className="lg:col-span-2 glass flex flex-col min-h-0">
          <div className="flex items-center justify-between p-3 border-b border-white/5">
            <span className="text-sm text-gray-400">main.jsx</span>
            <div className="flex gap-2">
              <button onClick={() => setShowPreview(!showPreview)} className="p-2 bg-neon-blue/20 rounded-lg text-neon-blue text-sm flex items-center gap-1">
                <FiPlay size={14} /> {showPreview ? 'Code' : 'Preview'}
              </button>
              <button className="p-2 bg-neon-purple/20 rounded-lg text-neon-purple text-sm flex items-center gap-1">
                <FiDownload size={14} /> Export
              </button>
            </div>
          </div>
          <div className="flex-1 min-h-0">
            {showPreview ? (
              <Preview code={code} />
            ) : (
              <CodeEditor value={code} onChange={setCode} />
            )}
          </div>
        </div>

        {/* AI Chat Assistant */}
        <div className="glass p-4 flex flex-col min-h-0">
          <ChatPanel title="Coding Assistant" />
        </div>
      </div>
    </div>
  );
}