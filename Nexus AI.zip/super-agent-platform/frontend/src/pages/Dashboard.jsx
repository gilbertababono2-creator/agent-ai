import { motion } from 'framer-motion';
import { FiCode, FiTrendingUp, FiCalendar, FiDollarSign, FiUsers, FiActivity } from 'react-icons/fi';
import AnalyticsCard from '../components/AnalyticsCard';
import ChatPanel from '../components/ChatPanel';

const stats = [
  { label: 'Apps Built', value: '24', icon: FiCode, change: '+12%' },
  { label: 'Content Generated', value: '156', icon: FiTrendingUp, change: '+23%' },
  { label: 'Appointments', value: '48', icon: FiCalendar, change: '+8%' },
  { label: 'Revenue', value: '$4,850', icon: FiDollarSign, change: '+18%' },
  { label: 'Active Users', value: '1.2k', icon: FiUsers, change: '+5%' },
  { label: 'AI Calls', value: '2.4k', icon: FiActivity, change: '+31%' },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <motion.h1 initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="text-2xl font-bold">
        Dashboard
      </motion.h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, i) => (
          <AnalyticsCard key={i} {...stat} index={i} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass p-5">
          <h3 className="text-lg font-semibold mb-4">Recent Projects</h3>
          <div className="space-y-3">
            {['AI SaaS Dashboard', 'E-commerce Backend', 'Portfolio Website', 'Chatbot API'].map((proj, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                <span>{proj}</span>
                <span className="text-sm text-gray-400">{`${i+1}d ago`}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="glass p-5 h-[400px]">
          <ChatPanel title="AI Assistant" />
        </div>
      </div>
    </div>
  );
}