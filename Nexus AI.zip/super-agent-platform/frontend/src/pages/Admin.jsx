import { motion } from 'framer-motion';
import AnalyticsCard from '../components/AnalyticsCard';
import { FiUsers, FiDollarSign, FiActivity, FiServer } from 'react-icons/fi';

const adminStats = [
  { label: 'Total Users', value: '2.4k', icon: FiUsers, change: '+18%' },
  { label: 'Monthly Revenue', value: '$12.8k', icon: FiDollarSign, change: '+24%' },
  { label: 'AI API Calls', value: '45.2k', icon: FiActivity, change: '+32%' },
  { label: 'System Uptime', value: '99.9%', icon: FiServer, change: 'Stable' },
];

export default function Admin() {
  return (
    <div className="space-y-6">
      <motion.h1 className="text-2xl font-bold">Admin Panel</motion.h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {adminStats.map((stat, i) => <AnalyticsCard key={i} {...stat} index={i} />)}
      </div>
      <div className="glass p-5">
        <h3 className="text-lg font-semibold mb-4">Recent Users</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-400 border-b border-white/5">
                <th className="text-left py-3">Email</th><th className="text-left">Plan</th><th className="text-left">Joined</th><th className="text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {[1,2,3].map(i => (
                <tr key={i} className="border-b border-white/5">
                  <td className="py-3">user{i}@example.com</td>
                  <td>{i===1 ? 'Premium' : 'Free'}</td>
                  <td>{new Date().toLocaleDateString()}</td>
                  <td><span className="text-green-400">Active</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}