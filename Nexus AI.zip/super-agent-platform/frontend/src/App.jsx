import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { useAuth } from './hooks/useAuth';
import Dashboard from './pages/Dashboard';
import AppBuilder from './pages/AppBuilder';
import Marketing from './pages/Marketing';
import Automation from './pages/Automation';
import Auth from './pages/Auth';
import Admin from './pages/Admin';
import Settings from './pages/Settings';
import Layout from './components/Layout';
import { Toaster } from 'react-hot-toast';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-neon-purple"></div></div>;
  if (!user) return <Navigate to="/auth" />;
  return children;
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster position="top-right" toastOptions={{ style: { background: '#1a1a1a', color: '#fff', border: '1px solid #333' } }} />
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/app-builder" element={<AppBuilder />} />
            <Route path="/marketing" element={<Marketing />} />
            <Route path="/automation" element={<Automation />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
export default App;