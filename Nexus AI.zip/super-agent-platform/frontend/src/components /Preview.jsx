import { useEffect, useRef } from 'react';

export default function Preview({ code }) {
  const iframeRef = useRef();

  useEffect(() => {
    const doc = iframeRef.current.contentDocument;
    doc.open();
    doc.write(`
      <html>
        <head>
          <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body><div id="root"></div></body>
        <script>
          // Simple Babel-like transform for JSX (limited, for demo)
          // In production you'd use a bundler
          try {
            ${code}
            ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
          } catch(e) {
            document.getElementById('root').innerHTML = '<p style="color:red">Error: ' + e.message + '</p>';
          }
        </script>
      </html>
    `);
    doc.close();
  }, [code]);

  return <iframe ref={iframeRef} className="w-full h-full border-0 bg-white" title="preview" />;
}