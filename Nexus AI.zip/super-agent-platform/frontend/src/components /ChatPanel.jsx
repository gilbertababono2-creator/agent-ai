import { useState } from 'react';
import { sendAgentMessage } from '../services/api';
import { FiSend } from 'react-icons/fi';

export default function ChatPanel({ title = "AI Chat" }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi! I can help you build apps, create content, or automate your business.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    const newMsgs = [...messages, { role: 'user', content: input }];
    setMessages(newMsgs);
    setInput('');
    setLoading(true);
    try {
      const res = await sendAgentMessage(input, messages);
      setMessages([...newMsgs, { role: 'assistant', content: res.data.reply }]);
    } catch (err) {
      setMessages([...newMsgs, { role: 'assistant', content: 'Sorry, something went wrong.' }]);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full">
      <h3 className="text-sm font-semibold mb-3 text-neon-blue">{title}</h3>
      <div className="flex-1 overflow-y-auto space-y-3 mb-4 pr-1">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-xl text-sm ${
              msg.role === 'user' 
                ? 'bg-neon-purple/20 border border-neon-purple/30' 
                : 'bg-white/5 border border-white/10'
            }`}>
              {msg.content}
            </div>
          </div>
        ))}
        {loading && <div className="text-gray-500 text-sm">Thinking...</div>}
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Ask anything..."
          className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-neon-purple focus:outline-none"
        />
        <button onClick={handleSend} className="p-2 bg-neon-purple/20 rounded-lg text-neon-purple hover:bg-neon-purple/30 transition-colors">
          <FiSend size={18} />
        </button>
      </div>
    </div>
  );
}