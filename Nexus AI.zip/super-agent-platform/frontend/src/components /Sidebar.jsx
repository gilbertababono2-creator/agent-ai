import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { FiHome, FiCode, FiTrendingUp, FiCalendar, FiSettings, FiShield, FiMenu, FiX } from 'react-icons/fi';
import { useAuth } from '../hooks/useAuth';
import { logout } from '../services/firebase';

const navItems = [
  { to: '/', icon: FiHome, label: 'Dashboard' },
  { to: '/app-builder', icon: FiCode, label: 'App Builder' },
  { to: '/marketing', icon: FiTrendingUp, label: 'Marketing' },
  { to: '/automation', icon: FiCalendar, label: 'Automation' },
  { to: '/admin', icon: FiShield, label: 'Admin' },
  { to: '/settings', icon: FiSettings, label: 'Settings' },
];

export default function Sidebar() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        className="fixed top-4 left-4 z-50 md:hidden text-white bg-glass-bg p-2 rounded-lg"
        onClick={() => setOpen(!open)}
      >
        {open ? <FiX size={24} /> : <FiMenu size={24} />}
      </button>

      {/* Overlay */}
      {open && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setOpen(false)} />}

      <aside className={`fixed md:static z-40 w-64 h-full bg-[#0d0d0d] border-r border-white/5 flex flex-col transition-transform duration-300 ${open ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
        <div className="p-6">
          <h1 className="text-xl font-bold bg-gradient-to-r from-neon-purple to-neon-blue bg-clip-text text-transparent">
            SuperAgent AI
          </h1>
        </div>
        <nav className="flex-1 px-3 space-y-1">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all ${
                  isActive 
                    ? 'bg-neon-purple/20 text-neon-purple neon-glow' 
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <item.icon size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <div className="flex items-center gap-3 mb-4">
            <img src={user?.photoURL || 'https://ui-avatars.com/api/?name=User&background=9D4EDD&color=fff'} alt="" className="w-8 h-8 rounded-full" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.displayName || user?.email}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full py-2 text-sm text-gray-400 hover:text-white transition-colors">
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
}