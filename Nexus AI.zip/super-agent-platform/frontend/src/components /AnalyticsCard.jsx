import { motion } from 'framer-motion';

export default function AnalyticsCard({ label, value, icon: Icon, change, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="glass p-5 hover:neon-glow transition-all"
    >
      <div className="flex justify-between items-start mb-3">
        <span className="text-gray-400 text-sm">{label}</span>
        <Icon className="text-neon-purple" size={20} />
      </div>
      <div className="text-2xl font-bold">{value}</div>
      <span className="text-xs text-green-400">{change}</span>
    </motion.div>
  );
}