import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const user = JSON.parse(localStorage.getItem('authUser') || '{}');
  if (user?.token) {
    config.headers.Authorization = `Bearer ${user.token}`;
  }
  return config;
});

export const sendAgentMessage = (message, conversationHistory) =>
  api.post('/agents/chat', { message, history: conversationHistory });

export const generateCode = (prompt, type) =>
  api.post('/agents/generate-code', { prompt, type });

export const generateContent = (type, topic, details) =>
  api.post('/agents/generate-content', { type, topic, details });

export const createAppointment = (data) =>
  api.post('/appointments', data);

export const initiateSubscription = (plan) =>
  api.post('/payments/subscribe', { plan });

export const verifyPayment = (reference) =>
  api.post('/payments/verify', { reference });

export default api;