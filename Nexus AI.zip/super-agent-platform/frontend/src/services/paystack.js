import PaystackPop from '@paystack/inline-js';

export const initializePaystackPayment = (email, amount, reference, onSuccess) => {
  const paystack = new PaystackPop();
  paystack.newTransaction({
    key: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY,
    email,
    amount: amount * 100, // convert to kobo
    ref: reference,
    onSuccess: (transaction) => {
      onSuccess(transaction);
    },
    onCancel: () => {
      console.log('Payment cancelled');
    }
  });
};