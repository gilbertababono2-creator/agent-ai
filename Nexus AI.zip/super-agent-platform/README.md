# SuperAgent AI Platform

All-in-one AI company OS: App Builder, Marketing Agent, Business Automation.

## Tech Stack
- **Frontend:** React + Vite + Tailwind CSS + Framer Motion
- **Backend:** Node.js + Express + Firebase Admin
- **Database:** Firestore
- **Auth:** Firebase Auth (Google, Email/Password)
- **Payments:** Paystack
- **AI:** OpenAI GPT-4 Turbo with multi‑agent routing

## Project Structure

## Setup

### Prerequisites
- Node.js 18+
- Firebase project with Firestore, Auth, and Hosting enabled
- Paystack account
- OpenAI API key

### Backend
```bash
cd backend
cp .env.example .env
# Fill in your keys
npm install
npm run dev